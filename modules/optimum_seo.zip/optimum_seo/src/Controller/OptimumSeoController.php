<?php

namespace Drupal/optimum_seo/Controller;
class OptimumSeoController {
    public funtion OptimumSEO() {
	return array(
	'title' => 'Hello World',
	'markup' => 'Optimum_SEO Test Page',
	);
    }

}
